/* 
 * File:   ArffData.cpp
 * Author: hans and victor
 * 
 * Created on 20 de Março de 2012, 14:31
 */

#include "ArffData.h"

