/* 
 * File:   Cluster.cpp
 * Author: hans
 * 
 * Created on 23 de Setembro de 2011, 10:41
 */

#include "Cluster.h"

