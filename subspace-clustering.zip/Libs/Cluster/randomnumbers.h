/* 
 * File:   randomnumbers.h
 * Author: hans
 *
 * Created on 22 de Setembro de 2011, 16:19
 */

#ifndef RANDOMNUMBERS_H
#define	RANDOMNUMBERS_H

double randomUniform(double low, double high);
double randomUniform01();
double randomGaussian(double m, double s);

#endif	/* RANDOMNUMBERS_H */

