#ifndef DLIB_REVISION_H
// Version:  18.17
// Date:     Sat Aug 15 22:24:34 EDT 2015
// Mercurial Revision ID:  ce6f36498786
#define DLIB_MAJOR_VERSION  18
#define DLIB_MINOR_VERSION  17
#endif
