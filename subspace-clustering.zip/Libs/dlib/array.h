// Copyright (C) 2003  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_ARRAy_
#define DLIB_ARRAy_

#include "array/array_kernel.h"
#include "array/array_tools.h"

#endif // DLIB_ARRAy_

