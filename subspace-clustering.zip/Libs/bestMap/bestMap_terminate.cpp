//
// File: bestMap_terminate.cpp
//
// MATLAB Coder version            : 2.6
// C/C++ source code generated on  : 20-Sep-2015 17:55:26
//

// Include files
#include "rt_nonfinite.h"
#include "bestMap.h"
#include "hungarian.h"
#include "bestMap_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void bestMap_terminate()
{
  // (no terminate code required)
}

//
// File trailer for bestMap_terminate.cpp
//
// [EOF]
//
