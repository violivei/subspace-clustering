//
// File: bestMap_initialize.h
//
// MATLAB Coder version            : 2.6
// C/C++ source code generated on  : 20-Sep-2015 17:55:26
//
#ifndef __BESTMAP_INITIALIZE_H__
#define __BESTMAP_INITIALIZE_H__

// Include files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "bestMap_types.h"

// Function Declarations
extern void bestMap_initialize();

#endif

//
// File trailer for bestMap_initialize.h
//
// [EOF]
//
