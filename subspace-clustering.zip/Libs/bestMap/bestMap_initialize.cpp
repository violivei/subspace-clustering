//
// File: bestMap_initialize.cpp
//
// MATLAB Coder version            : 2.6
// C/C++ source code generated on  : 20-Sep-2015 17:55:26
//

// Include files
#include "rt_nonfinite.h"
#include "bestMap.h"
#include "hungarian.h"
#include "bestMap_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void bestMap_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for bestMap_initialize.cpp
//
// [EOF]
//
