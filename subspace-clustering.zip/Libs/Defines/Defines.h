#ifndef DEFINES_H_INCLUDED
#define DEFINES_H_INCLUDED

//Include debug output functions
#include "DebugOut.h"
#include <iomanip>

//Common types
typedef unsigned int uint;
#define qrt(x) ((x)*(x))
//#define min(x,y) (x<y?x:y)
//#define max(x,y) (x>y?x:y)

#endif // DEFINES_H_INCLUDED
