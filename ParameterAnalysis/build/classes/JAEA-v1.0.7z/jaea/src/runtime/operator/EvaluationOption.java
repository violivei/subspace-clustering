package runtime.operator;
import org.w3c.dom.Element;
/**
 * Parser for evaluation operator
 * @author Le Minh Nghia, NTU-Singapore
 *
 */
public class EvaluationOption extends Operator{
	public EvaluationOption(Element elem)
	{
		Name = "Evaluation";
	}
	public String toString()
	{
		String res = "";
		res += "Operator = " + this.Name + "\n"; 
		return res;
	}
}
