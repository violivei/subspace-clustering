package runtime.operator;

/**
 * Abstract parser for operator
 * @author Le Minh Nghia, NTU-Singapore
 *
 */
public abstract class Operator {
	public String Name;
	public String toString()
	{
		String res = "";
		res += "Operator = " + this.Name + "\n"; 
		return res;
	}
}
