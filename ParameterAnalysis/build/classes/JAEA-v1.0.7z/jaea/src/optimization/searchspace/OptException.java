package optimization.searchspace;

public class OptException extends Exception
{
    private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * @param msg
	 */
    public OptException(String msg)
    {
        super(msg);
    }
}
